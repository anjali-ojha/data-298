import numpy as np
import streamlit as st


st.title("Page 1")
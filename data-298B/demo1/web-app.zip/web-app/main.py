import pathlib

import streamlit as st

from streamlit_option_menu import option_menu
import os

# from dotenv import load_dotenv

# load_dotenv()

import home, account, about, tune_a_video



def load_css(file_name):
    with open(file_name) as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)


st.set_page_config(
    page_title="Text-To-Video",
    layout='wide',
)

st.markdown(
    """
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src=f"https://www.googletagmanager.com/gtag/js?id={os.getenv('analytics_tag')}"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', os.getenv('analytics_tag'));
            [data-testid="stAppViewContainer"] {
                background-color: #e5e5f7;
                opacity: 0.8;
                background-image:  repeating-radial-gradient( circle at 0 0, transparent 0, #e5e5f7 10px ), repeating-linear-gradient( #444cf755, #444cf7 );
            }
            
            [data-testid="stHeader"] {
                background-color: rgba(0, 0, 0, 0);
                color: white;   
            }
            
            [data-testid="stToolbar"] {
                background-color: #000000;
                color: white;
                right: 2em;
            }
            
            [data-testid="stSidebar"] {
                backGround-image: url('https://www.transparenttextures.com/patterns/brushed-alum.png');
            }
        </script>
    """, unsafe_allow_html=True)
print(os.getenv('analytics_tag'))


class MultiApp:

    def __init__(self):
        self.apps = []

    def add_app(self, title, func):

        self.apps.append({
            "title": title,
            "function": func
        })

    def run(self):
        load_css(pathlib.Path('assets/style.css'))
        # app = st.sidebar(
        with st.sidebar:
            # st.sidebar.image('https://i.gifer.com/embedded/download/VYY.gif')
            st.sidebar.image('assets/images/logo.png')
            app = option_menu(
                menu_title='Text-To-Video ',
                options=['Home', 'Tune-A-Video Model', 'CogVideoX-5b Model', 'ZeroScope Model', 'Account', 'about'],
                icons=['house-fill', 'person-circle', 'trophy-fill', 'chat-fill', 'info-circle-fill'],
                menu_icon='chat-text-fill',
                default_index=0,
                styles={
                    "container": {"padding": "5!important", "background-color": 'black'},
                    "icon": {"color": "white", "font-size": "23px"},
                    "nav-link": {"color": "white", "font-size": "20px", "text-align": "left", "margin": "0px",
                                 "--hover-color": "blue"},
                    "nav-link-selected": {"background-color": "#02ab21"}, }

            )

        if app == "Home":
            home.app()
        if app == "Account":
            account.app()
        if app == "Tune-A-Video Model":
            tune_a_video.app()
        if app == "CogVideoX-5b Model":
            tune_a_video.app()
        if app == "ZeroScope Model":
            tune_a_video.app()
        if app == 'About':
            about.app()

if __name__ == "__main__":
    runner = MultiApp()
    runner.run()
